#pragma once
#include "Core/Core.h"

namespace kiko
{
	struct Particle
	{
		Vector2 position;
		Vector2 velocity;
		Color color;
	};
}
